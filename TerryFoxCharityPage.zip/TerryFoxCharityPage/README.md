Terry Fox Charity Page I created as a Canadian. It is color themed with Canada and with the traditional colors of medicine. Hope you like 
-Stephen Kassaw